function n = numel(varargin)
%NUMEL        Overloaded functions, necessary for Matlab V6.1f
%

% written  10/03/02     S.M. Rump
% modified 04/04/04     S.M. Rump  set round to nearest for safety
% modified 04/06/05     S.M. Rump  rounding unchanged
%

  n = 1;
