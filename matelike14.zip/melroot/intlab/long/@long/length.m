function r = length(a)
%LENGTH       Long length length(a)
%

% written  04/11/98     S.M. Rump
% modified 04/04/04     S.M. Rump  set round to nearest for safety
% modified 04/06/05     S.M. Rump  rounding unchanged
%

  r = length(a.sign);
