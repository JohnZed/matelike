function C = ldivide(A,B)
%LDIVIDE      Long left division  A .\ B  (same as B / A)
%
%Division always entrywise
%

% written  11/02/05     S.M. Rump
%

  C = B / A;
