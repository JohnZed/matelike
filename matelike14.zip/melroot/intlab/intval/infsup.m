function c = infsup(a,b)
%INFSUP       Initialization of interval by infimum and supremum
%  computed such that [a,b] is enclosed in interval  c
%
%   c = infsup(a,b)
%

% written  10/16/98     S.M. Rump
% modified 12/06/98     S.M. Rump  NaN test added
% modified 06/24/99     S.M. Rump  check sparsity, multi-dimensional arrays
% modified 09/02/00     S.M. Rump  rounding unchanged after use
% modified 04/07/04     S.M. Rump  very large linear index
% modified 04/04/04     S.M. Rump  set round to nearest for safety
% modified 04/06/05     S.M. Rump  rounding unchanged
% modified 11/02/05     S.M. Rump  large indices
%

  if issparse(a)~=issparse(b)
    error('midpoint and radius must both be or none of them be sparse')
  end

  if ~isreal(a) | ~isreal(b)       % complex interval
    index = ( real(a)>real(b) ) | ( imag(a)>imag(b) );
    if any(index(:))
      error('improper intervals in call of infsup')
    end
    global INTLAB_INTVAL_CINFSUPASGN
    if INTLAB_INTVAL_CINFSUPASGN
      warning('complex interval defined by infsup(zinf,zsup) will be stored in mid/rad causing overestimation')
    end
    rndold = getround;
    setround(1)
    cmid = a + 0.5*(b - a);
    crad = max( abs(cmid-a) , abs(cmid-b) ) ;
    setround(rndold)
    c = intval(cmid,crad,'midrad');
  else                             % real interval (inf/sup representation)
    index = any(any( a>b ));
    if prod(size(index))~=1
      index = any(index(:));
    end
    if index                       % take care of very large linear index
      error('improper intervals in call of infsup')
    end
    c = intval(a,b,'infsup');
  end

  index = isnan(a) | isnan(b);
  nanindex = any(any(index));
  if prod(size(nanindex))~=1
    nanindex = any(nanindex(:));
  end
  if nanindex                      % take care of very large linear index
    c(index) = NaN;
  end
