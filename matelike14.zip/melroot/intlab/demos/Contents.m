% DEMOS
%
% Files
%   dintlab     - DEMOINTLAB   A little demonstration of INTLAB
%   dintval     - some simple demonstrations of some INTLAB routines
%   dgradient   - DEMOGRADIENT Short demonstration of gradients
%   dhessian    - DEMOHESSIAN  Short demonstration of hessians
%   dpolynom    - Demo of some functionalities of polynom toolbox
%   dslope      - DEMOSLOPE    Short demonstration of slopes
%   dlong       - DEMOLONG Short demonstration of long numbers
%